package administracaoEscolar;

public abstract class Pessoa {
    
    String nome;
    String identificacao;
    String dataInicio;
    
    public abstract void exibirInformacoes();
}