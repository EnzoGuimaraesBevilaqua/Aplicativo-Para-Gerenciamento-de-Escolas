package administracaoEscolar;

public class Diretor extends Pessoa{
    
    Diretor(String nome, String identificacao, String dataInicio)
    {
        this.nome = nome;
        this.identificacao = identificacao;
        this.dataInicio = dataInicio;
    }
}